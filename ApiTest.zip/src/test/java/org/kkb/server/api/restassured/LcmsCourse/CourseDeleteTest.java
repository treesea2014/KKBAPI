package org.kkb.server.api.restassured.LcmsCourse;

/**
 * Created by www on 2015/7/20.
 * 课程删除测试暂未实现
 */
public class CourseDeleteTest {


}
