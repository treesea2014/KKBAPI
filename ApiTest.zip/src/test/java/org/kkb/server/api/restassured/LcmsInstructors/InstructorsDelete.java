package org.kkb.server.api.restassured.LcmsInstructors;

/**
 * Created by www on 2015/7/27.
 */
public class InstructorsDelete {
}
