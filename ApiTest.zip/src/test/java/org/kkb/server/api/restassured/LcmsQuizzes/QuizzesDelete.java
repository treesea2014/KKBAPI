package org.kkb.server.api.restassured.LcmsQuizzes;

/**
 * Created by www on 2015/7/27.
 */
public class QuizzesDelete {
}
